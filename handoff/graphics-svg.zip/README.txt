Комплекс-Техно. Векторная графика для верстальщика

В архиве экспорт из Figma. Соответствие имён файлов и исходных слоёв — в figma-sources.tsv.
UI Kit: https://www.figma.com/design/afhjmp3eRNMG3RdmToLG1f/Untitled?node-id=1804-2608

Пример установки: installation-desktop.svg — графика без подсказок.
installation-hotspots-desktop.svg — расположение точек. Точки интерфейса реализуются кнопками, чтобы они работали с клавиатуры и касанием.
installation-mobile-canvas.svg и sensor-mobile-canvas.svg — полные адаптивные холсты вместе с маркерами. Применяйте видимые окна из документации.
Состояние «Стало» — repair-after.svg. Компоновку и механику сверяйте по graphics-handoff.html и документации.
